
__author__ = "Andy Dustman <farcepest@gmail.com>"
version_info = (1,3,12,'final',0)
__version__ = "1.3.12"
